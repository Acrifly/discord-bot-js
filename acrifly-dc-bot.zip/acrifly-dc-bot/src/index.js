const {memberNicknameMention} = require('@discordjs/builders');
const Discord = require('discord.js');
const client = new Discord.Client({intents: [Discord.Intents.FLAGS.GUILDS, Discord.Intents.FLAGS.GUILD_MESSAGES]});
const{MessageEmbed} = require('discord.js');

client.once("ready", () => {
  console.log(`Ready! Logged in as ${client.user.tag}! I'm on ${client.guilds.cache.size} guild(s)!`)
  client.user.setActivity({name: "Fortnite", type: "PLAYING"})
})



client.on("messageCreate", message => {
  if (message.author.bot) return;
  // This is where we'll put our code.
  if (message.content.indexOf(config.prefix) !== 0) return;

  const args = message.content.slice(config.prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();

  if (command === 'ping') {
    message.channel.send('Pong!');
  } else

  if (command === 'blah') {
    message.channel.send('Meh.');
  }
});

client.login("")